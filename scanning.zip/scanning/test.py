#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:	0.01
#Create:	2016-01-08
#Authoruis:	kun/

import os

class Traversal(object):
	list = []
	#遍历目录
	def traversal_dir(self, filepath, prin=False):
		#遍历filepath下所有文件，包括子目录
		files = os.listdir(filepath)
		for fi in files:
			fi_d = os.path.join(filepath,fi)            
			if os.path.isdir(fi_d):
				self.traversal_dir(fi_d, prin)        
			else:
				if prin :
					print os.path.join(filepath,fi_d)
				self.list.append(os.path.join(filepath,fi_d))#添加遍历到的文件
		return self.list

	def print_files(self):
		for ls in self.list:
			print ls
	

	def test(self):
		#递归遍历所有文件
		self.traversal_dir('/usr/develop/Beebeeto-framework/utils')
		self.print_files()


if __name__ == '__main__':

	traversal = Traversal()
	traversal.test()

