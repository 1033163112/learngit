#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:       0.01
#Create:        2016-01-08
#Authoruis:     kun/

import os  
import re  

class Operation(object):
	
	
	#读取文件
	def read(self, filepath):
		file_object = open(filepath)
		try:
			return file_object.read()
		finally:
			file_object.close()
        
	#将text写入文件
	def write(self, filepath, text, type):
		file_object = open(filepath, type)
                try:
                        file_object.write(text)
                finally:
                        file_object.close()
	
	#将一个list写入文件，无换行
	def writeList(self, list, type):
		file_object = open(filepath, type)
                try:
                        file_object.f.writelines(list)
                finally:
                        file_object.close()

	

	#查找filepath文件内容是否包含str字符串 
	#不包含返回	-1
	def find(self, filepath, str):
		file_text = self.read(filepath)
		return file_text.lower().find(str.lower())

	def findListStr(self, filepath, strList):
		file_text = self.read(filepath)
		for str in strList:
			if file_text.lower().find(str.lower()) != -1:
				print str , "\t\t==>",filepath
			file_text.lower().find(str.lower())

	def test(self):	
		print self.findListStr("/root/scanning/test.jpg",['root', 'lower'])


if __name__ == '__main__':
	fileopt = Operation();
	fileopt.test();
