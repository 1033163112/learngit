#!/usr/bin/python
# -*- coding: utf-8 -*-

#Version:	0.01
#Create:	2016-01-08
#Authoruis:	kun/

import sys
import traversal_dir
import operation

class Scanning(object):
	traversal = traversal_dir.Traversal()
	operation = operation.Operation();
	#木马特征
	list = ['.exec(', 'shell', 'cmd']
	def start(self):
		self.cmp(sys.argv[1], self.list)	

	#查找木马
	def cmp(self, dir, features):
		file_list = self.traversal.traversal_dir(dir)
		for file in file_list:
			self.operation.findListStr(file, features)

			

if __name__ == '__main__':
	scan = Scanning()
	scan.start()
		
